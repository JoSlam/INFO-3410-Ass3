from django.contrib import admin
from django.urls import path
from django.conf.urls import url,include
from . import views

urlpatterns = [
    #/
    url(r'^$', views.show_list , name='index'),

    #/anime/list
    url(r'^anime/list/$', views.show_list , name='index'),

    #/anime/<anime_id>/
    url(r'^anime/(?P<anime_id>[0-9]+)$', views.show_detail, name='details'),

    #/anime/add_anime/
    url(r'^anime/add_anime/$', views.add_anime, name='add_anime'),

    #/anime/upload/
    url(r'^anime/upload/$', views.upload_anime, name='upload_anime')
]