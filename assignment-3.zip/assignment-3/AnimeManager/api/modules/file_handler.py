import csv
from api.models import Anime

def file_handler(file):
    arr = []
    csv_file = csv.DictReader(file)
    for row in csv_file:
        anime, created = Anime.objects.get_or_create(
            anime_id=row['anime_id'],
            name=row['name'],
            genre=row['genre'],
            anime_type=row['type'],
            episodes=row['episodes'],
            rating=row['rating'],
            members=row['members']
        )
        arr.append({'name': anime.name, 'created': created})
    return arr