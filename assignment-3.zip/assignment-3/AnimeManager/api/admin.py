from django.contrib import admin

# Register your models here.
from api.animes import Anime

admin.site.register(Anime)