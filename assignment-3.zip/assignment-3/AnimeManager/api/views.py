from django.shortcuts import render, get_object_or_404
from django.http import HttpResponseRedirect, HttpResponse
from django.core.paginator import Paginator
from django.core.files.storage import FileSystemStorage
import csv
import os

#model imports
from .models import Anime, AnimeForm, Document, DocumentForm

#module imports
from .modules import file_handler

def save_dat(request):
    with open('/home/adminuser/Desktop/assignment-3/AnimeManager/api/static/data/anime.csv', 'r') as readF:
        reader = csv.reader(readF)
        arr = []
        for row in reader:
            if row[0] != 'anime_id':
                anime, created = Anime.objects.get_or_create(
                    anime_id = int(row[0]),
                    name = row[1],
                    genre = row[2],
                    animeType = row[3],
                    episodes = row[4],
                    rating = row[5],
                    members = int(row[6])
                )
                arr.append({'anime': anime, 'created':created})
    return render(request, 'anime/index.html', {'data': arr})


#display list of all anime 50 at a time
def show_list(request):
    all_anime = Anime.objects.all()
    page = request.GET.get('page')
    paginator = Paginator(all_anime, 50)
    current_page = paginator.get_page(page)

    return render(request, 'anime/index.html', {'all_anime': current_page})


#display details for selected anime
def show_detail(request, anime_id):
    anime = get_object_or_404(Anime, pk=anime_id)
    return render(request, 'anime/detail.html', {'anime': anime})
    

#add new anime via form
def add_anime(request):
    aniForm = AnimeForm()

    if request.method == 'POST':
        aniForm = AnimeForm(request.POST)
        if aniForm.is_valid():
            anime, created = Anime.objects.get_or_create(**aniForm.cleaned_data)
            return HttpResponseRedirect('/anime/add_anime')

    return render(request, 'anime/new_anime.html', {'form': aniForm})



#add new anime via file upload
def upload_anime(request):
    docForm = DocumentForm()

    if request.method == 'POST':
        docForm = DocumentForm(request.POST, request.FILES)
        if docForm.is_valid():
            docForm.save()
            name = request.FILES['document'].name
            with open('documents/'+name, 'r') as readFile:
                created_anime = file_handler(readFile)
            os.remove('documents/'+name)

        #use this to build a table to show that status of the submitted entries
        for anime in created_anime:
            print(anime['name'], anime['created'])
        return HttpResponseRedirect('/anime/upload')            
         
    return render(request, 'anime/upload_anime.html', {'form': docForm})