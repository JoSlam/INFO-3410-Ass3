from .anime import Anime
from .animeForm import AnimeForm

from .upload_doc import Document
from .upload_doc_form import DocumentForm