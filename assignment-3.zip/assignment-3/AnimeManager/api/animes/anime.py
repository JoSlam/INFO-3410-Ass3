from django.db import models
from django.db.models import (
    CharField,
    IntegerField,
    FloatField
)

class Anime(models.Model):
    anime_id = IntegerField(primary_key = True)
    name = CharField(max_length=250)
    genre = CharField(max_length=150)
    anime_type = CharField(max_length=15)
    episodes = CharField(max_length=15)
    rating = CharField(max_length=5)
    members = IntegerField()

    class Meta:
        ordering = ('anime_id',)

    def __str__(self):
        return self.name