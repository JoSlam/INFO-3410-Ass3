from django.db import models
from api.animes import Anime, AnimeForm, Document, DocumentForm